# ============================================================
# UDB v1.1  PLL G4  — Full Analysis Suite
mol new dendrimer_pll_gen4_solvated.prmtop type amber waitfor all
mol addfile 04_npt_equil.dcd type dcd waitfor all
mol addfile 05_production.dcd type dcd waitfor all
set nframes [molinfo top get numframes]
puts "Loaded $nframes frames"

# Atom selections
set den_heavy  [atomselect top "not water and not name Na Cl and not name H*"]
set den_all    [atomselect top "not water and not name Na Cl"]
set water_O    [atomselect top "water and name O"]
set terminal_N [atomselect top "not water and name N* and not name Na and numbonds 1"]

# Output files
set o_rg     [open "dendrimer_pll_gen4_Rg.dat"       w]
set o_delta  [open "dendrimer_pll_gen4_delta.dat"    w]
set o_rmsd   [open "dendrimer_pll_gen4_RMSD.dat"     w]
set o_ee     [open "dendrimer_pll_gen4_end2end.dat"  w]
set o_rdens  [open "dendrimer_pll_gen4_rdensity.dat" w]
puts $o_rg    "# Frame  Time_ns  Rg_heavy_A  Rg_all_A"
puts $o_delta "# Frame  Time_ns  delta  lambda1  lambda2  lambda3"
puts $o_rmsd  "# Frame  Time_ns  RMSD_A"
puts $o_ee    "# Frame  Time_ns  max_ee_dist_A  mean_ee_dist_A"
puts $o_rdens "# Frame  Time_ns  shell_Rg  density_at_0.5Rg  density_at_Rg  density_at_1.5Rg"

# Reference for RMSD (first frame)
$den_heavy frame 0
set ref_pos [$den_heavy get {x y z}]

for {set fr 0} {$fr < $nframes} {incr fr} {
    $den_heavy frame $fr
    $den_all   frame $fr

    # ── Centre of mass ──────────────────────────────────────────────────────
    set coords_h [$den_heavy get {x y z}]
    set coords_a [$den_all   get {x y z}]
    set n_h [llength $coords_h]
    set n_a [llength $coords_a]
    set cx 0; set cy 0; set cz 0
    foreach c $coords_h {
            set cx [expr {$cx+[lindex $c 0]}]
            set cy [expr {$cy+[lindex $c 1]}]
            set cz [expr {$cz+[lindex $c 2]}]
    }
    set cx [expr {$cx/$n_h}]; set cy [expr {$cy/$n_h}]; set cz [expr {$cz/$n_h}]

    # ── Rg heavy ────────────────────────────────────────────────────────────
    set rg2_h 0
    set Gxx 0; set Gyy 0; set Gzz 0
    set Gxy 0; set Gxz 0; set Gyz 0
    foreach c $coords_h {
            set dx [expr {[lindex $c 0]-$cx}]
            set dy [expr {[lindex $c 1]-$cy}]
            set dz [expr {[lindex $c 2]-$cz}]
            set rg2_h [expr {$rg2_h+$dx*$dx+$dy*$dy+$dz*$dz}]
            set Gxx [expr {$Gxx+$dx*$dx}]; set Gyy [expr {$Gyy+$dy*$dy}]; set Gzz [expr {$Gzz+$dz*$dz}]
            set Gxy [expr {$Gxy+$dx*$dy}]; set Gxz [expr {$Gxz+$dx*$dz}]; set Gyz [expr {$Gyz+$dy*$dz}]
    }
    set rg_h [expr {sqrt($rg2_h/$n_h)}]
    set Gxx [expr {$Gxx/$n_h}]; set Gyy [expr {$Gyy/$n_h}]; set Gzz [expr {$Gzz/$n_h}]
    set Gxy [expr {$Gxy/$n_h}]; set Gxz [expr {$Gxz/$n_h}]; set Gyz [expr {$Gyz/$n_h}]

    # ── Rg all atoms ────────────────────────────────────────────────────────
    set cx2 0; set cy2 0; set cz2 0
    foreach c $coords_a {
            set cx2 [expr {$cx2+[lindex $c 0]}]
            set cy2 [expr {$cy2+[lindex $c 1]}]
            set cz2 [expr {$cz2+[lindex $c 2]}]
    }
    set cx2 [expr {$cx2/$n_a}]; set cy2 [expr {$cy2/$n_a}]; set cz2 [expr {$cz2/$n_a}]
    set rg2_a 0
    foreach c $coords_a {
            set dx [expr {[lindex $c 0]-$cx2}]
            set dy [expr {[lindex $c 1]-$cy2}]
            set dz [expr {[lindex $c 2]-$cz2}]
            set rg2_a [expr {$rg2_a+$dx*$dx+$dy*$dy+$dz*$dz}]
    }
    set rg_a [expr {sqrt($rg2_a/$n_a)}]
    set t_ns [expr {$fr*2500*2.0/1e6}]
    puts $o_rg [format "%6d  %8.3f  %8.3f  %8.3f" $fr $t_ns $rg_h $rg_a]

    # ── Asphericity delta ────────────────────────────────────────────────────
    set I1 [expr {$Gxx+$Gyy+$Gzz}]
    set I2 [expr {$Gxx*$Gyy+$Gyy*$Gzz+$Gxx*$Gzz-$Gxy*$Gxy-$Gxz*$Gxz-$Gyz*$Gyz}]
    set delta [expr {abs($I1)>1e-10 ? 1.0-3.0*$I2/($I1*$I1) : 0.0}]
    puts $o_delta [format "%6d  %8.3f  %8.5f  %8.3f  %8.3f  %8.3f"             $fr $t_ns $delta $Gxx $Gyy $Gzz]

    # ── RMSD ────────────────────────────────────────────────────────────────
    set curr_pos [$den_heavy get {x y z}]
    set rmsd2 0
    foreach c $curr_pos r $ref_pos {
            set dx [expr {[lindex $c 0]-[lindex $r 0]}]
            set dy [expr {[lindex $c 1]-[lindex $r 1]}]
            set dz [expr {[lindex $c 2]-[lindex $r 2]}]
            set rmsd2 [expr {$rmsd2+$dx*$dx+$dy*$dy+$dz*$dz}]
    }
    set rmsd [expr {sqrt($rmsd2/$n_h)}]
    puts $o_rmsd [format "%6d  %8.3f  %8.3f" $fr $t_ns $rmsd]

    # ── End-to-end distances (terminal heavy atoms → core centre) ────────────
    $terminal_N frame $fr
    set tn_coords [$terminal_N get {x y z}]
    if {[llength $tn_coords] > 0} {
            set max_ee 0; set sum_ee 0; set n_ee 0
            foreach c $tn_coords {
                set dx [expr {[lindex $c 0]-$cx}]
                set dy [expr {[lindex $c 1]-$cy}]
                set dz [expr {[lindex $c 2]-$cz}]
                set d [expr {sqrt($dx*$dx+$dy*$dy+$dz*$dz)}]
                if {$d > $max_ee} {set max_ee $d}
                set sum_ee [expr {$sum_ee+$d}]; incr n_ee
            }
            set mean_ee [expr {$n_ee>0 ? $sum_ee/$n_ee : 0}]
            puts $o_ee [format "%6d  %8.3f  %8.3f  %8.3f" $fr $t_ns $max_ee $mean_ee]
    }

    # ── Radial density (atoms per shell at 0.5*Rg, Rg, 1.5*Rg) ─────────────
    set r1 [expr {$rg_h*0.5}]; set r2 $rg_h; set r3 [expr {$rg_h*1.5}]
    set dr 1.0; set vol [expr {4*3.14159*$r2*$r2*$dr}]
    set n1 0; set n2 0; set n3 0
    foreach c $coords_h {
            set dx [expr {[lindex $c 0]-$cx}]
            set dy [expr {[lindex $c 1]-$cy}]
            set dz [expr {[lindex $c 2]-$cz}]
            set d [expr {sqrt($dx*$dx+$dy*$dy+$dz*$dz)}]
            if {$d>=$r1-$dr&&$d<$r1+$dr} {incr n1}
            if {$d>=$r2-$dr&&$d<$r2+$dr} {incr n2}
            if {$d>=$r3-$dr&&$d<$r3+$dr} {incr n3}
    }
    puts $o_rdens [format "%6d  %8.3f  %8.3f  %8.4f  %8.4f  %8.4f"             $fr $t_ns $rg_h             [expr {$n1/(4*3.14159*$r1*$r1*$dr)}]             [expr {$vol>0 ? $n2/$vol : 0}]             [expr {$n3/(4*3.14159*$r3*$r3*$dr)}]]

    if {$fr%100==0} {
            puts "Frame $fr/$nframes  t=[format %.1f $t_ns]ns  Rg=[format %.2f $rg_h]A  delta=[format %.4f $delta]"
            flush stdout
    }
}
close $o_rg; close $o_delta; close $o_rmsd; close $o_ee; close $o_rdens
puts "
Analysis complete:"
puts "  dendrimer_pll_gen4_Rg.dat          — radius of gyration vs time"
puts "  dendrimer_pll_gen4_delta.dat       — asphericity vs time"
puts "  dendrimer_pll_gen4_RMSD.dat        — RMSD from equilibrated structure"
puts "  dendrimer_pll_gen4_end2end.dat     — arm end-to-end distances"
puts "  dendrimer_pll_gen4_rdensity.dat    — radial density profile"
puts "
Reference (Maiti 2004 PAMAM G3): Rg~14-19A, delta<0.05"
quit
