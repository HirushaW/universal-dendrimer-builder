#!/bin/bash
# ============================================================
# UDB v1.1  PPI G1  — NPT continuation script
# Use this when step 4 (NPT equilibration) fails with:
#   "Periodic cell has become too small for original patch grid"
#
# What it does:
#   1. Patches 04_npt_equil.conf / 05_production.conf /
#      05_production_restart.conf  (adds margin, slows piston)
#   2. Re-runs run_namd.sh — steps 1-3 are skipped automatically
#      because their restart files already exist.
#
# Usage:
#   bash continue_npt.sh           (uses same core count as run_namd.sh)
#   bash continue_npt.sh 32        (override core count)
# ============================================================

set -e
NCORES="${1:-24}"
NAMD_BIN="/home/hirushawalgampaya/Documents/NAMD_3.0.2/namd3"
NAMD="$NAMD_BIN +p$NCORES"

RED='\033[0;31m'; GRN='\033[0;32m'; CYN='\033[0;36m'
YLW='\033[1;33m'; WHT='\033[1;37m'; NC='\033[0m'
ok()   { echo -e "${GRN}  [OK]${NC} $1"; }
err()  { echo -e "${RED}  [ERROR]${NC} $1"; }
info() { echo -e "${CYN}  $1${NC}"; }
warn() { echo -e "${YLW}  [WARN]${NC} $1"; }

echo ""
echo -e "${WHT}============================================================${NC}"
echo -e "${WHT}  UDB v1.1  NPT continuation — PPI G1${NC}"
echo -e "${WHT}  Cores: $NCORES  |  Start: $(date)${NC}"
echo -e "${WHT}============================================================${NC}"

# ── Guard: make sure steps 1-3 are actually done ─────────────────────────────
for f in 01_minimize.restart.coor 02_heat.restart.coor 03_nvt_equil.restart.coor \
         01_minimize.restart.vel  02_heat.restart.vel  03_nvt_equil.restart.vel  \
         01_minimize.restart.xsc  02_heat.restart.xsc  03_nvt_equil.restart.xsc; do
    if [ ! -f "$f" ]; then
        err "Missing checkpoint: $f"
        err "Steps 1-3 must be complete before using this script."
        exit 1
    fi
done
ok "Steps 1-3 checkpoint files verified"

# ── Patch conf files ──────────────────────────────────────────────────────────
patch_conf() {
    local conf="$1"
    [ ! -f "$conf" ] && warn "$conf not found — skipping" && return
    cp "$conf" "${conf}.bak"

    # Add margin 5.0 after langevinPistonTemp (idempotent — skip if already present)
    if ! grep -q "^margin" "$conf"; then
        sed -i '/^langevinPistonTemp/a margin              5.0' "$conf"
        ok "  $conf — added margin 5.0"
    else
        ok "  $conf — margin already present"
    fi

    # Slow piston: period 200→500, decay 100→250
    sed -i 's/^langevinPistonPeriod[[:space:]]\+[0-9.]\+/langevinPistonPeriod    500.0/' "$conf"
    sed -i 's/^langevinPistonDecay[[:space:]]\+[0-9.]\+/langevinPistonDecay     250.0/'  "$conf"
    ok "  $conf — piston period/decay set to 500/250 fs"
}

info "Patching NPT conf files..."
patch_conf 04_npt_equil.conf
patch_conf 05_production.conf
patch_conf 05_production_restart.conf

# ── Remove any partial step-4 output so run_namd.sh re-runs it ───────────────
if [ -f "04_npt_equil.restart.coor" ]; then
    warn "Partial step-4 restart files found — removing so step 4 reruns cleanly"
    rm -f 04_npt_equil.restart.coor \
          04_npt_equil.restart.vel  \
          04_npt_equil.restart.xsc  \
          04_npt_equil.restart.coor.BAK \
          04_npt_equil.restart.vel.BAK  \
          04_npt_equil.restart.xsc.BAK
    ok "Partial step-4 files removed"
fi

# ── Validate NAMD binary ──────────────────────────────────────────────────────
if [ ! -x "$NAMD_BIN" ] && ! command -v "$NAMD_BIN" &>/dev/null; then
    err "NAMD binary not found: $NAMD_BIN"
    err "Edit NAMD_BIN= at the top of this script."
    exit 1
fi

mkdir -p logs

echo ""
info "Resuming from step 4 (NPT equilibration)..."
echo ""

# STEP 4 — NPT equilibration
info "[4/5] NPT equilibration  300 K / 1 atm..."
$NAMD 04_npt_equil.conf > logs/04_npt_equil.log 2>&1
if [ $? -ne 0 ]; then
    err "NPT equilibration failed — check logs/04_npt_equil.log"
    tail -30 logs/04_npt_equil.log
    exit 1
fi
ok "NPT equilibration complete"

# STEP 5 — NPT production
echo ""
info "[5/5] NPT production..."
$NAMD 05_production.conf > logs/05_production.log 2>&1
if [ $? -ne 0 ]; then
    err "Production failed — check logs/05_production.log"
    tail -30 logs/05_production.log
    exit 1
fi
ok "Production complete"

echo ""
echo -e "${WHT}============================================================${NC}"
echo    "  NPT continuation complete!  $(date)"
echo    "  To restart production if killed:  bash run_namd.sh restart"
echo -e "${WHT}============================================================${NC}"
