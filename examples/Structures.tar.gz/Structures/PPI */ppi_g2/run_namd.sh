#!/bin/bash
# UDB v1.1  PPI G2  Complete NAMD Pipeline
# Usage:          bash run_namd.sh
# Restart prod:   bash run_namd.sh restart
# Custom cores:   bash run_namd.sh 32
# Required in this folder:
#   dendrimer_ppi_gen2_typed.mol2    (from UDB AMBER pipeline)
#   dendrimer_ppi_gen2.frcmod        (from UDB AMBER pipeline)
# All other files are generated automatically.

NAMD_BIN="/home/hirushawalgampaya/Documents/NAMD_3.0.2/namd3"
NCORES="${1:-24}"
NAMD="$NAMD_BIN +p$NCORES"
# T10: GPU-resident dynamics launch — NAMD 3 wants ~1 PE per GPU; extra cores
# slow it down. Minimisation (01) keeps the multi-core CPU launch ($NAMD).
NAMD_GPU="$NAMD_BIN +p1 +setcpuaffinity +devices 0"
mkdir -p logs

# ── Colour output helpers ─────────────────────────────────────────────────────
RED='[0;31m'; GRN='[0;32m'; YLW='[1;33m'
CYN='[0;36m'; WHT='[1;37m'; NC='[0m'
ok()   { echo -e "${GRN}  [OK]${NC} $1"; }
err()  { echo -e "${RED}  [ERROR]${NC} $1"; }
info() { echo -e "${CYN}  $1${NC}"; }
warn() { echo -e "${YLW}  [WARN]${NC} $1"; }

# ── Restart mode ─────────────────────────────────────────────────────────────
RESTART_MODE=0
if [ "$1" = "restart" ]; then
    RESTART_MODE=1
    NCORES="${2:-24}"
    NAMD="$NAMD_BIN +p$NCORES"
fi

echo ""
echo -e "${WHT}======================================================${NC}"
echo -e "${WHT}  UDB v1.1  PPI G2  NAMD Pipeline${NC}"
echo -e "${WHT}  NAMD:    $NAMD_BIN${NC}"
echo -e "${WHT}  Cores:   $NCORES  |  Start: $(date)${NC}"
echo -e "${WHT}======================================================${NC}"

# ── Validate binary ───────────────────────────────────────────────────────────
if [ -f "$NAMD_BIN" ] && [ -x "$NAMD_BIN" ]; then
    :
elif command -v "$NAMD_BIN" >/dev/null 2>&1; then
    NAMD_BIN="$(command -v "$NAMD_BIN")"
    NAMD="$NAMD_BIN +p$NCORES"
else
    err "NAMD binary not found or not executable: $NAMD_BIN"
    err "Edit NAMD_BIN= at the top of this script or add it to PATH."
    exit 1
fi

# ── Validate input files ──────────────────────────────────────────────────────
for f in "dendrimer_ppi_gen2_typed.mol2" "dendrimer_ppi_gen2.frcmod"; do
    if [ ! -f "$f" ]; then
            err "Required file missing: $f"
            err "Run UDB AMBER Fragment BCC pipeline first."
            exit 1
    fi
done
ok "Input files verified"

# ── Handle restart mode ───────────────────────────────────────────────────────
if [ $RESTART_MODE -eq 1 ]; then
    if [ ! -f "05_production.restart.coor" ]; then
            err "No production restart file found (05_production.restart.coor)"
            err "Cannot restart — no previous production run detected."
            exit 1
    fi
    info "RESTART MODE: resuming production from last checkpoint..."
    # Read last timestep from xsc file
    LAST_TS=$(tail -1 05_production.restart.xsc | awk '{print $1}')
    sed -i "s/firsttimestep.*FIRSTTIMESTEP/firsttimestep       $LAST_TS/"             05_production_restart.conf
    info "Resuming from timestep $LAST_TS"
    $NAMD 05_production_restart.conf >> logs/05_production.log
    [ $? -ne 0 ] && { err "Restart failed — check logs/05_production.log"; exit 1; }
    ok "Production restart complete"
    echo ""
    echo -e "${WHT}======================================================"
    echo -e "  Restart complete!  $(date)${NC}"
    exit 0
fi

# STEP 0 — tLeap solvation
echo ""
info "[0/5] tLeap solvation (TIP3P, 15 A padding)..."
if [ ! -f "dendrimer_ppi_gen2_solvated.prmtop" ]; then
    if [ -f "dendrimer_ppi_gen2_typed.mol2" ]; then
        MOL2_CHARGE=$(python3 -c "
import sys
total=0.0
in_atom=False
for l in open("dendrimer_ppi_gen2_typed.mol2"):
    if '@<TRIPOS>ATOM' in l: in_atom=True; continue
    if l.startswith('@'): in_atom=False
    if in_atom:
        p=l.split()
        if len(p)>=9:
            try: total+=float(p[8])
            except: pass
print(max(0, round(abs(total))))
" 2>/dev/null || echo "0")
        if [ "$MOL2_CHARGE" -gt 0 ] 2>/dev/null; then
            warn "[v1.1] Fractional charge detected — adding $MOL2_CHARGE Na+ ions"
            sed -i "s/addionsrand mol Na+ __NACL_COUNT__ Cl- 0/addionsrand mol Na+ $MOL2_CHARGE Cl- 0/" 00_solvate.tleap
        else
            sed -i "s/addionsrand mol Na+ __NACL_COUNT__ Cl- 0/addionsrand mol Na+ 0 Cl- 0/" 00_solvate.tleap
        fi
    else
        sed -i "s/addionsrand mol Na+ __NACL_COUNT__ Cl- 0/addionsrand mol Na+ 0 Cl- 0/" 00_solvate.tleap
    fi
    tleap -f 00_solvate.tleap 2>&1 | tee logs/00_solvate.log
    if [ ! -f "dendrimer_ppi_gen2_solvated.prmtop" ]; then
            err "tLeap failed — check logs/00_solvate.log"
            exit 1
    fi

    # ── Auto-read actual box from inpcrd and patch all conf files ────────────
    BOX_LINE=$(tail -1 dendrimer_ppi_gen2_solvated.inpcrd)
    BX=$(echo $BOX_LINE | awk '{print $1}')
    BY=$(echo $BOX_LINE | awk '{print $2}')
    BZ=$(echo $BOX_LINE | awk '{print $3}')
    CX=$(echo "$BX / 2" | bc -l | xargs printf "%.4f")
    CY=$(echo "$BY / 2" | bc -l | xargs printf "%.4f")
    CZ=$(echo "$BZ / 2" | bc -l | xargs printf "%.4f")

    # ── PME grid: re-compute from actual box ─────────────────────────────────
    PME_FUNC() {
            python3 -c "
import math, sys
n = math.ceil(float(sys.argv[1]))
while True:
    x = n
    for p in [2,3,5]:
            while x%p==0: x//=p
    if x==1: print(n); break
    n+=1
" $1
    }
    PX=$(PME_FUNC $BX); PY=$(PME_FUNC $BY); PZ=$(PME_FUNC $BZ)

    info "  Actual box: ${BX} x ${BY} x ${BZ} A"
    info "  PME grid:   ${PX} x ${PY} x ${PZ}"
    info "  Cell origin: ${CX}  ${CY}  ${CZ}"

    # Patch 01_minimize.conf with real values
    sed -i "s/cellBasisVector1.*/cellBasisVector1    $BX  0.0    0.0/"  01_minimize.conf
    sed -i "s/cellBasisVector2.*/cellBasisVector2    0.0    $BY  0.0/"  01_minimize.conf
    sed -i "s/cellBasisVector3.*/cellBasisVector3    0.0    0.0    $BZ/" 01_minimize.conf
    sed -i "s/cellOrigin.*/cellOrigin          $CX  $CY  $CZ/"         01_minimize.conf
    for conf in 01_minimize.conf 02_heat.conf 03_nvt_equil.conf                     04_npt_equil.conf 05_production.conf 05_production_restart.conf; do
            [ -f "$conf" ] &&             sed -i "s/PMEGridSizeX.*/PMEGridSizeX        $PX/" $conf &&             sed -i "s/PMEGridSizeY.*/PMEGridSizeY        $PY/" $conf &&             sed -i "s/PMEGridSizeZ.*/PMEGridSizeZ        $PZ/" $conf
    done
    ok "cellBasisVector + PME grid patched from actual inpcrd"

else
    ok "Solvated files found — skipping tLeap"
    BX=$(tail -1 dendrimer_ppi_gen2_solvated.inpcrd | awk '{print $1}')
    BY=$(tail -1 dendrimer_ppi_gen2_solvated.inpcrd | awk '{print $2}')
    BZ=$(tail -1 dendrimer_ppi_gen2_solvated.inpcrd | awk '{print $3}')
    info "  Existing box: ${BX} x ${BY} x ${BZ} A"
fi

python3 - << 'PYEND'
import sys
with open("dendrimer_ppi_gen2_solvated.pdb") as f: lines = f.readlines()
out = []
for l in lines:
    if l[:4] in ("ATOM","HETA"):
            name = l[12:16].strip()
            resn = l[17:20].strip()
            is_water = resn in ("WAT","HOH","TIP","TP3")
            is_ion   = name in ("Na","Cl","NA","CL")
            is_H     = name.startswith("H") or name.startswith("h")
            bfac = "0.00" if (is_water or is_ion or is_H) else "1.00"
            out.append(l[:60] + f"{bfac:>6}" + l[66:])
    else:
            out.append(l)
with open("dendrimer_ppi_gen2_restrained.pdb","w") as f: f.writelines(out)
heavy = sum(1 for l in out if l[:4] in ("ATOM","HETA") and l[12:16].strip()[:1] not in ("H","h"))
print(f"  Restraint PDB: dendrimer_ppi_gen2_restrained.pdb  ({heavy} constrained heavy atoms)")
PYEND
ok "Restraint PDB regenerated from current solvated structure"

# STEP 1 — Energy minimisation
echo ""
info "[1/5] Energy minimisation (5000 steps)..."
if [ ! -f "01_minimize.restart.coor" ] || [ ! -f "01_minimize.restart.vel" ] || [ ! -f "01_minimize.restart.xsc" ]; then
    $NAMD 01_minimize.conf > logs/01_minimize.log 2>&1
    if [ $? -ne 0 ]; then
            err "Minimisation failed"
            tail -30 logs/01_minimize.log
            exit 1
    fi
    ok "Minimisation complete"
else
    ok "Skipping — restart file found"
fi

# STEP 2 — NVT heating 0 → 300 K
echo ""
info "[2/5] NVT heating  0 → 300 K  (200 ps)..."
if [ ! -f "02_heat.restart.coor" ] || [ ! -f "02_heat.restart.vel" ] || [ ! -f "02_heat.restart.xsc" ]; then
    $NAMD 02_heat.conf > logs/02_heat.log 2>&1
    if [ $? -ne 0 ]; then
            err "Heating failed"
            tail -30 logs/02_heat.log
            exit 1
    fi
    ok "Heating complete"
else
    ok "Skipping — restart file found"
fi

# STEP 3 — NVT equilibration 500 ps
echo ""
info "[3/5] NVT equilibration at 300 K  (500 ps)..."
if [ ! -f "03_nvt_equil.restart.coor" ] || [ ! -f "03_nvt_equil.restart.vel" ] || [ ! -f "03_nvt_equil.restart.xsc" ]; then
    $NAMD 03_nvt_equil.conf > logs/03_nvt_equil.log 2>&1
    if [ $? -ne 0 ]; then
            err "NVT equilibration failed"
            tail -30 logs/03_nvt_equil.log
            exit 1
    fi
    ok "NVT equilibration complete"
else
    ok "Skipping — restart file found"
fi

# STEP 4 — NPT equilibration 2 ns
echo ""
info "[4/5] NPT equilibration  300 K / 1 atm  (2 ns)..."
if [ ! -f "04_npt_equil.restart.coor" ] || [ ! -f "04_npt_equil.restart.vel" ] || [ ! -f "04_npt_equil.restart.xsc" ]; then
    $NAMD 04_npt_equil.conf > logs/04_npt_equil.log 2>&1
    if [ $? -ne 0 ]; then
            err "NPT equilibration failed"
            tail -30 logs/04_npt_equil.log
            exit 1
    fi
    ok "NPT equilibration complete"
else
    ok "Skipping — restart file found"
fi

# STEP 5 — NPT production 10 ns
echo ""
info "[5/5] NPT production  300 K  (10 ns)..."
info "      Estimated trajectory: ~2.4 GB"
$NAMD 05_production.conf > logs/05_production.log 2>&1
if [ $? -ne 0 ]; then
    err "Production failed"
    tail -30 logs/05_production.log
    exit 1
fi
ok "Production complete"

echo ""
info "Running VMD analysis..."
if command -v vmd &>/dev/null; then
    vmd -dispdev none -e analysis.tcl > logs/analysis.log 2>&1
    ok "Analysis complete"
    info "  Output files:"
    for f in dendrimer_ppi_gen2_Rg.dat dendrimer_ppi_gen2_delta.dat dendrimer_ppi_gen2_RMSD.dat                  dendrimer_ppi_gen2_end2end.dat dendrimer_ppi_gen2_rdensity.dat; do
            [ -f "$f" ] && echo "    $f"
    done
else
    warn "VMD not found — skipping analysis"
    warn "Run manually: vmd -e analysis.tcl"
fi

echo ""
echo -e "${WHT}======================================================"
echo    "  Pipeline complete!  $(date)"
echo    "  To restart if killed:  bash run_namd.sh restart"
echo -e "======================================================${NC}"
